/*! For license information please see 223e9aa2c094c1672837c90.js.LICENSE.txt */
"use strict";(self.webpackChunkupgrade4me=self.webpackChunkupgrade4me||[]).push([[223],{223:function(e,p,u){u.d(p,{initializeApp:function(){return a.Wp}});var a=u(461);(0,a.KO)("firebase","11.1.0","app")}}]);
//# sourceMappingURL=223e9aa2c094c1672837c90.js.map